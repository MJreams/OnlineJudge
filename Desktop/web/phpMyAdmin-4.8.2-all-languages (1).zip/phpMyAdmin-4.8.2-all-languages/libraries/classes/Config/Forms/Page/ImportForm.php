<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * User preferences form
 *
 * @package PhpMyAdmin
 */
namespace PhpMyAdmin\Config\Forms\Page;

class ImportForm extends \PhpMyAdmin\Config\Forms\User\ImportForm
{
}
